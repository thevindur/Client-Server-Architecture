/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ict2client;

/**
 *
 * @author Asus
 */
public class ICT2Client {

    /**
     * @param args the command line arguments
     * @throws ict2client.Exception_Exception
     */
    public static void main(String[] args) throws Exception_Exception {
        ICT2Client client = new ICT2Client();
        client.execute();
        // TODO code application logic here
    }

    private void execute() throws Exception_Exception {
        System.out.println("[CLIENT] - Start Testing");
        if(isConnected() == 0){
            System.out.println("[CLIENT] - Server Connected");
            double x = 4;
            double y = 2;
            double z = divide(x,y);
            System.out.println("[CLIENT] - " + x + " divided by " + y + " is " + z);
            x = 2.6;
            y = 1.6;
            z = divide(x,y);
            System.out.println("[CLIENT] - " + x + " divided by " + y + " is " + z);
            x = 3.3;
            y = 1.5;
            double t = 4.2;
            System.out.println("[CLIENT] - adding " + x + ", " + y + ", " + t + " to ArrayList");
            addDoubleOnServer(x);
            addDoubleOnServer(y);
            addDoubleOnServer(t);
            try{
            x = 2;
            y = 0;
            double k = safeDivide(x,y);
            System.out.println(x + " safe divided by " + y + " is " + k);
            }
            catch(Exception_Exception ex){
                System.out.println("Error");
            }
            
            double c = getLargestDoubleOnServer();
            System.out.println("[CLIENT] - Largest double on the list is " + c);
            
           
        }else
            System.out.println("[CLIENT] - Server is not Connected");
        System.out.println("[CLIENT] - Testing Completed");
    }

    private static Integer isConnected() {
        ict2client.ICT2WebService_Service service = new ict2client.ICT2WebService_Service();
        ict2client.ICT2WebService port = service.getICT2WebServicePort();
        return port.isConnected();
    }

    private static Double divide(java.lang.Double x, java.lang.Double y) {
        ict2client.ICT2WebService_Service service = new ict2client.ICT2WebService_Service();
        ict2client.ICT2WebService port = service.getICT2WebServicePort();
        return port.divide(x, y);
    }

    private static void addDoubleOnServer(java.lang.Double a) {
        ict2client.ICT2WebService_Service service = new ict2client.ICT2WebService_Service();
        ict2client.ICT2WebService port = service.getICT2WebServicePort();
        port.addDoubleOnServer(a);
    }

    

    private static Double getLargestDoubleOnServer() {
        ict2client.ICT2WebService_Service service = new ict2client.ICT2WebService_Service();
        ict2client.ICT2WebService port = service.getICT2WebServicePort();
        return port.getLargestDoubleOnServer();
    }

    private static Double safeDivide(java.lang.Double x, java.lang.Double y) throws Exception_Exception {
        ict2client.ICT2WebService_Service service = new ict2client.ICT2WebService_Service();
        ict2client.ICT2WebService port = service.getICT2WebServicePort();
        return port.safeDivide(x, y);
    }



    
    
    
    
    
    
    
}
