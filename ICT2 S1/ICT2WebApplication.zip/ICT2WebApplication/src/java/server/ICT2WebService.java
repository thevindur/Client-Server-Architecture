/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package server;

import java.util.ArrayList;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author Asus
 */
@WebService(serviceName = "ICT2WebService")
public class ICT2WebService {
    ArrayList<Double> doubles = new ArrayList();

    /**
     * This is a sample web service operation
     */
    @WebMethod(operationName = "hello")
    public String hello(@WebParam(name = "name") String txt) {
        return "Hello " + txt + " !";
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "isConnected")
    public Integer isConnected() {
        System.out.println("[SERVER] - Testing Connection...");
        //TODO write your implementation code here:
        return 0;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "divide")
    public Double divide(@WebParam(name = "x") Double x, @WebParam(name = "y") Double y) {
        //TODO write your implementation code here:
        return x/y;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "addDoubleOnServer")
    public void addDoubleOnServer(@WebParam(name = "a") Double a) {
        //TODO write your implementation code here:
        System.out.println("[SERVER] - Passing double value...");
        doubles.add(a);
        System.out.println("[SERVER] - value successfully added to ArrayList");
        System.out.println(doubles);
        
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "safeDivide")
    public Double safeDivide(@WebParam(name = "x") Double x, @WebParam(name = "y") Double y) throws Exception {
        //TODO write your implementation code here:
        if(x == null && y == null){
            throw new Exception();
        }
        else if(y == 0){
            throw new Exception();
        }
        else{
            return x/y;
        }
        }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "getLargestDoubleOnServer")
    public Double getLargestDoubleOnServer() {
        System.out.println("[SERVER] - Searching for the largest double on the server");
        int n = doubles.size();
        double max = doubles.get(0);
         for (int i = 1; i < n; i++) {
            if (doubles.get(i) > max) {
                max = doubles.get(i);
            }
        }
         System.out.println("[SERVER] - Largest value found");
        //TODO write your implementation code here:
        return max;
        
    }
    }



