/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package server;

/**
 *
 * @author rog
 */
public class BooleanContainer {
    Boolean a;

    public Boolean getA() {
        return a;
    }

    public void setA(Boolean a) {
        this.a = a;
    }
    
}
